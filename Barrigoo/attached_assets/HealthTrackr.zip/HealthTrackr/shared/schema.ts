import { pgTable, text, serial, integer, boolean, date, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("user_id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password_hash"),  // Optional for social login
  googleId: text("google_id").unique(),
  githubId: text("github_id").unique(),
  dietaryPreferences: jsonb("dietary_preferences").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  lastLogin: timestamp("last_login"),
  isEmailVerified: boolean("is_email_verified").default(false),
});

export const categories = pgTable("categories", {
  id: serial("category_id").primaryKey(),
  name: text("category_name").notNull().unique(),
});

export const ingredients = pgTable("ingredients", {
  id: serial("ingredient_id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category"),
  unit: text("unit").default("g"),
});

export const nutritionalInfo = pgTable("nutritional_info", {
  id: serial("nutrition_id").primaryKey(),
  ingredientId: integer("ingredient_id").references(() => ingredients.id, { onDelete: 'cascade' }),
  cookingMethod: text("cooking_method"),
  nutrition: jsonb("nutrition").default({}),
});

export const meals = pgTable("meals", {
  id: serial("meal_id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: 'cascade' }),
  name: text("meal_name").notNull(),
  categoryId: integer("category_id").references(() => categories.id, { onDelete: 'set null' }),
  nutrition: jsonb("nutrition").default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mealIngredients = pgTable("meal_ingredients", {
  mealId: integer("meal_id").references(() => meals.id, { onDelete: 'cascade' }),
  ingredientId: integer("ingredient_id").references(() => ingredients.id, { onDelete: 'cascade' }),
  quantity: integer("quantity").notNull(),
  unit: text("unit"),
  cookingMethod: text("cooking_method"),
});

export const foodHabits = pgTable("food_habits", {
  id: serial("habit_id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: 'cascade' }),
  name: text("habit_name").notNull(),
  frequency: text("frequency"),
  startDate: date("start_date").notNull(),
  status: text("status").default("active"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  googleId: true,
  githubId: true,
  dietaryPreferences: true,
}).partial({
  password: true,  // Make password optional for social login
  googleId: true,
  githubId: true,
});

export const insertMealSchema = createInsertSchema(meals).pick({
  userId: true,
  name: true,
  categoryId: true,
  nutrition: true,
});

export const insertFoodHabitSchema = createInsertSchema(foodHabits).pick({
  userId: true,
  name: true,
  frequency: true,
  startDate: true,
  status: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Meal = typeof meals.$inferSelect;
export type InsertMeal = z.infer<typeof insertMealSchema>;
export type FoodHabit = typeof foodHabits.$inferSelect;
export type InsertFoodHabit = z.infer<typeof insertFoodHabitSchema>;