import { db } from "./db";
import { eq } from "drizzle-orm";
import {
  users, meals, foodHabits,
  type User, type InsertUser,
  type Meal, type InsertMeal,
  type FoodHabit, type InsertFoodHabit,
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Meal operations
  getMealsByUserId(userId: number): Promise<Meal[]>;
  createMeal(meal: InsertMeal): Promise<Meal>;
  deleteMeal(id: number): Promise<void>;

  // Food Habit operations
  getHabitsByUserId(userId: number): Promise<FoodHabit[]>;
  createHabit(habit: InsertFoodHabit): Promise<FoodHabit>;
  updateHabit(id: number, habit: Partial<InsertFoodHabit>): Promise<FoodHabit>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getMealsByUserId(userId: number): Promise<Meal[]> {
    return await db.select().from(meals).where(eq(meals.userId, userId));
  }

  async createMeal(meal: InsertMeal): Promise<Meal> {
    const [created] = await db.insert(meals).values(meal).returning();
    return created;
  }

  async deleteMeal(id: number): Promise<void> {
    await db.delete(meals).where(eq(meals.id, id));
  }

  async getHabitsByUserId(userId: number): Promise<FoodHabit[]> {
    return await db.select().from(foodHabits).where(eq(foodHabits.userId, userId));
  }

  async createHabit(habit: InsertFoodHabit): Promise<FoodHabit> {
    const [created] = await db.insert(foodHabits).values(habit).returning();
    return created;
  }

  async updateHabit(id: number, habit: Partial<InsertFoodHabit>): Promise<FoodHabit> {
    const [updated] = await db
      .update(foodHabits)
      .set(habit)
      .where(eq(foodHabits.id, id))
      .returning();
    if (!updated) throw new Error("Habit not found");
    return updated;
  }
}

export const storage = new DatabaseStorage();