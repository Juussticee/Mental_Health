import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMealSchema, insertFoodHabitSchema, insertUserSchema } from "@shared/schema";
import bcrypt from "bcryptjs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);

      // Check if user exists
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);

      // Create user
      const user = await storage.createUser({
        ...data,
        password: hashedPassword,
        dietaryPreferences: {},
      });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid registration data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(401).json({ message: "Invalid login data" });
    }
  });

  // Meals
  app.get("/api/meals/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const meals = await storage.getMealsByUserId(userId);
    res.json(meals);
  });

  app.post("/api/meals", async (req, res) => {
    const meal = insertMealSchema.parse(req.body);
    const created = await storage.createMeal(meal);
    res.json(created);
  });

  app.delete("/api/meals/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteMeal(id);
    res.sendStatus(200);
  });

  // Food Habits
  app.get("/api/habits/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const habits = await storage.getHabitsByUserId(userId);
    res.json(habits);
  });

  app.post("/api/habits", async (req, res) => {
    const habit = insertFoodHabitSchema.parse(req.body);
    const created = await storage.createHabit(habit);
    res.json(created);
  });

  app.patch("/api/habits/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const update = insertFoodHabitSchema.partial().parse(req.body);
    const updated = await storage.updateHabit(id, update);
    res.json(updated);
  });

  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  const httpServer = createServer(app);
  return httpServer;
}