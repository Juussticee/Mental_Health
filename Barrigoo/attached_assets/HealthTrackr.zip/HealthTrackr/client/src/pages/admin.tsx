import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { UserManagement } from "@/components/admin/UserManagement";
import { SystemAnalytics } from "@/components/admin/SystemAnalytics";
import { AnalyticsAndReports } from "@/components/admin/AnalyticsAndReports";
import { HealthQuests } from "@/components/gamification/HealthQuests";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { User } from "@shared/schema";

export default function Admin() {
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList>
            <TabsTrigger value="analytics">Analytics & Reports</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="gamification">Health Quests</TabsTrigger>
            <TabsTrigger value="system">System Overview</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-6">
            <AnalyticsAndReports />
          </TabsContent>

          <TabsContent value="users">
            <UserManagement users={users} />
          </TabsContent>

          <TabsContent value="gamification">
            <HealthQuests />
          </TabsContent>

          <TabsContent value="system">
            <SystemAnalytics />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}