import { AppLayout } from "@/components/layout/AppLayout";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import type { Meal, FoodHabit } from "@shared/schema";

export default function CalendarPage() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const userId = 1; // TODO: Get from auth context

  const { data: meals = [] } = useQuery<Meal[]>({
    queryKey: ["/api/meals", userId],
  });

  const { data: habits = [] } = useQuery<FoodHabit[]>({
    queryKey: ["/api/habits", userId],
  });

  const selectedDateMeals = meals.filter(
    (meal) => format(new Date(meal.createdAt!), "yyyy-MM-dd") === format(date!, "yyyy-MM-dd")
  );

  const activeHabits = habits.filter(h => h.status === "active");
  const nextHabit = activeHabits[0]; // Show the first active habit as the next one to focus on

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Calendar</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendar View</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          <div className="space-y-6">
            {nextHabit && (
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>Next Habit to Focus On</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{nextHabit.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {nextHabit.frequency} habit - Started on {new Date(nextHabit.startDate).toLocaleDateString()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Daily Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <h3 className="font-medium">Meals</h3>
                  {selectedDateMeals.map((meal) => (
                    <div
                      key={meal.id}
                      className="p-4 rounded-lg bg-accent"
                    >
                      <h4 className="font-medium">{meal.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {(meal.nutrition as any).calories || 0} calories
                      </p>
                    </div>
                  ))}

                  <h3 className="font-medium mt-6">Active Habits</h3>
                  {activeHabits.map((habit) => (
                    <div
                      key={habit.id}
                      className="p-4 rounded-lg bg-accent"
                    >
                      <h4 className="font-medium">{habit.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {habit.frequency} habit
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}