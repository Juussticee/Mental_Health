import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { CalorieCounter } from "@/components/dashboard/CalorieCounter";
import { DailyGoals } from "@/components/dashboard/DailyGoals";
import { MealList } from "@/components/dashboard/MealList";
import { Button } from "@/components/ui/button";
import { Plus, Brain } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Meal, FoodHabit } from "@shared/schema";

export default function Dashboard() {
  const [_, setLocation] = useLocation();
  const userId = 1; // TODO: Get from auth context

  const { data: meals = [] } = useQuery<Meal[]>({
    queryKey: ["/api/meals", userId],
  });

  const { data: habits = [] } = useQuery<FoodHabit[]>({
    queryKey: ["/api/habits", userId],
  });

  const deleteMeal = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/meals/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meals", userId] });
    },
  });

  const updateHabit = useMutation({
    mutationFn: async (id: number) => {
      const habit = habits.find((h) => h.id === id);
      if (!habit) return;

      await apiRequest("PATCH", `/api/habits/${id}`, {
        status: habit.status === "completed" ? "active" : "completed",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits", userId] });
    },
  });

  const totalCalories = meals.reduce((sum, meal) => sum + ((meal.nutrition as any).calories || 0), 0);
  const calorieGoal = 2000; // TODO: Get from user settings

  const todaysMeals = meals.filter(meal => {
    const mealDate = new Date(meal.createdAt!).toDateString();
    const today = new Date().toDateString();
    return mealDate === today;
  });

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Today</h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setLocation("/ai")}>
              <Brain className="h-4 w-4 mr-2" />
              AI Assistant
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Meal
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid gap-8">
          {/* Calories Section */}
          <div className="flex justify-center">
            <div className="w-full max-w-md">
              <CalorieCounter consumed={totalCalories} goal={calorieGoal} />
            </div>
          </div>

          {/* Goals and Meals Section */}
          <div className="grid md:grid-cols-2 gap-6">
            <DailyGoals habits={habits} />
            <MealList
              meals={todaysMeals}
              onDelete={(id) => deleteMeal.mutate(id)}
            />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}