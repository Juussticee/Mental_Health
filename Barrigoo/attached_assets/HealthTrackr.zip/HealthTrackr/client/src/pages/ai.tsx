import { AppLayout } from "@/components/layout/AppLayout";
import { RecipeGenerator } from "@/components/ai/RecipeGenerator";
import { MealPlanner } from "@/components/ai/MealPlanner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain } from "lucide-react";

export default function AI() {
  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-2">
          <Brain className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">AI Assistant</h1>
        </div>

        <div className="grid gap-8">
          <RecipeGenerator />
          
          <Card>
            <CardHeader>
              <CardTitle>Meal Planning Assistant</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Get personalized meal plans based on your lifestyle, health conditions, and nutrition goals.
              </p>
              <MealPlanner />
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
