import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Target } from "lucide-react";
import { motion } from "framer-motion";

interface Quest {
  id: number;
  title: string;
  description: string;
  progress: number;
  reward: string;
  deadline: string;
}

const weeklyQuests: Quest[] = [
  {
    id: 1,
    title: "Protein Champion",
    description: "Meet your daily protein goals for 5 days straight",
    progress: 60,
    reward: "Gold Badge",
    deadline: "3 days left",
  },
  {
    id: 2,
    title: "Veggie Victory",
    description: "Add vegetables to 10 meals this week",
    progress: 40,
    reward: "Health Points x2",
    deadline: "5 days left",
  },
  {
    id: 3,
    title: "Meal Prep Master",
    description: "Log 3 prepared meals in advance",
    progress: 33,
    reward: "Silver Badge",
    deadline: "6 days left",
  },
];

export function HealthQuests() {
  const [quests, setQuests] = useState(weeklyQuests);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Weekly Health Quests</h2>
          <p className="text-muted-foreground">Complete quests to earn rewards!</p>
        </div>
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          <span className="font-bold">250 Points</span>
        </div>
      </div>

      <div className="grid gap-4">
        {quests.map((quest) => (
          <motion.div
            key={quest.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    {quest.title}
                    {quest.progress >= 100 && (
                      <Star className="h-5 w-5 text-yellow-500" />
                    )}
                  </CardTitle>
                  <span className="text-sm text-muted-foreground">
                    {quest.deadline}
                  </span>
                </div>
                <CardDescription>{quest.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span>Progress</span>
                    <span>{quest.progress}%</span>
                  </div>
                  <Progress value={quest.progress} />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      <Target className="h-4 w-4" />
                      <span>Reward: {quest.reward}</span>
                    </div>
                    <Button
                      size="sm"
                      variant={quest.progress >= 100 ? "outline" : "default"}
                      disabled={quest.progress >= 100}
                    >
                      {quest.progress >= 100 ? "Completed" : "Track Progress"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
