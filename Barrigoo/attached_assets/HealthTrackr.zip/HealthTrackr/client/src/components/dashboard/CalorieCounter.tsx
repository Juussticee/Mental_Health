import { Card, CardContent } from "@/components/ui/card";
import { CircularProgress } from "@/components/ui/circular-progress";

interface CalorieCounterProps {
  consumed: number;
  goal: number;
}

export function CalorieCounter({ consumed, goal }: CalorieCounterProps) {
  const remaining = Math.max(goal - consumed, 0);

  return (
    <Card className="relative overflow-hidden">
      <CardContent className="pt-6 flex flex-col items-center text-center">
        <CircularProgress value={consumed} max={goal} className="mb-4" />

        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 translate-y-4">
          <div className="space-y-1">
            <p className="text-4xl font-bold text-primary">
              {remaining}
            </p>
            <p className="text-sm text-muted-foreground">
              calories remaining
            </p>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-3 gap-4 w-full">
          <div>
            <p className="text-sm font-medium">Goal</p>
            <p className="text-lg">{goal}</p>
          </div>
          <div>
            <p className="text-sm font-medium">Eaten</p>
            <p className="text-lg">{consumed}</p>
          </div>
          <div>
            <p className="text-sm font-medium">Remaining</p>
            <p className="text-lg">{remaining}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}