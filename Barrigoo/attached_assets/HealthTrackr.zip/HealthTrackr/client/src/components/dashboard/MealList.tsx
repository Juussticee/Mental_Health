import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import type { Meal } from "@shared/schema";

interface MealListProps {
  meals: Meal[];
  onDelete: (id: number) => void;
}

export function MealList({ meals, onDelete }: MealListProps) {
  const mealTimes = [
    { label: "Breakfast", time: "05:00-11:00" },
    { label: "Lunch", time: "11:00-16:00" },
    { label: "Dinner", time: "16:00-22:00" },
    { label: "Snacks", time: "Any time" },
  ];

  // TODO: Add proper meal categorization based on time
  const getMealTimeCategory = (meal: Meal) => {
    const hour = new Date(meal.createdAt!).getHours();
    if (hour >= 5 && hour < 11) return "Breakfast";
    if (hour >= 11 && hour < 16) return "Lunch";
    if (hour >= 16 && hour < 22) return "Dinner";
    return "Snacks";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Today's Meals</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {mealTimes.map((mealTime) => {
            const categoryMeals = meals.filter(
              (meal) => getMealTimeCategory(meal) === mealTime.label
            );

            return (
              <div key={mealTime.label} className="space-y-2">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">{mealTime.label}</h3>
                  <span className="text-sm text-muted-foreground">
                    {mealTime.time}
                  </span>
                </div>

                {categoryMeals.length > 0 ? (
                  <div className="space-y-2">
                    {categoryMeals.map((meal) => (
                      <div
                        key={meal.id}
                        className="flex items-center justify-between p-3 bg-accent rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium">{meal.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {(meal.nutrition as any).calories || 0} calories
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(meal.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground py-2">
                    No meals recorded
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}