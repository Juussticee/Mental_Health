import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import { Link } from "wouter";
import type { FoodHabit } from "@shared/schema";

interface DailyGoalsProps {
  habits: FoodHabit[];
}

export function DailyGoals({ habits }: DailyGoalsProps) {
  const activeHabits = habits.filter(h => h.status === "active");

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Today's Goals</CardTitle>
        <Link href="/calendar">
          <Button variant="ghost" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            Calendar
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activeHabits.map((habit) => (
            <div key={habit.id} className="space-y-2">
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">{habit.name}</p>
                <p className="text-sm text-muted-foreground">
                  {habit.status === "completed" ? "Completed" : "In Progress"}
                </p>
              </div>
              <Progress
                value={habit.status === "completed" ? 100 : 0}
                className="h-2"
              />
            </div>
          ))}
          {activeHabits.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">
              No goals set for today. Visit the calendar to add some!
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
