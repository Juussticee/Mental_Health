import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import type { FoodHabit } from "@shared/schema";

interface HabitTrackerProps {
  habits: FoodHabit[];
  onToggle: (habitId: number) => void;
}

export function HabitTracker({ habits, onToggle }: HabitTrackerProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Food Habits</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {habits.map((habit) => (
          <div key={habit.id} className="space-y-2">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={habit.status === "completed"}
                onCheckedChange={() => onToggle(habit.id)}
              />
              <span>{habit.name}</span>
            </div>
            <div className="text-sm text-muted-foreground">
              {habit.frequency} habit since {new Date(habit.startDate).toLocaleDateString()}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}