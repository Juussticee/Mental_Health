import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Plus, Clock, Utensils } from "lucide-react";

const MOOD_EMOJIS = {
  great: "😊",
  good: "🙂",
  okay: "😐",
  notGood: "😕",
  bad: "😢"
};

const TIMING_RECOMMENDATIONS = {
  breakfast: "7:00 AM - 9:00 AM",
  morningSnack: "10:00 AM - 11:00 AM",
  lunch: "12:00 PM - 2:00 PM",
  afternoonSnack: "3:00 PM - 4:00 PM",
  dinner: "6:00 PM - 8:00 PM"
};

export function MealTracker() {
  const [selectedMood, setSelectedMood] = useState<keyof typeof MOOD_EMOJIS | null>(null);
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Meal logged successfully!",
      description: `Your meal was recorded with mood: ${MOOD_EMOJIS[selectedMood!]}`,
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Utensils className="h-5 w-5" />
          Smart Meal Tracker
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Meal Input */}
          <div className="space-y-2">
            <Label>What did you eat?</Label>
            <Input placeholder="Enter your meal..." />
          </div>

          {/* Mood Selection */}
          <div className="space-y-2">
            <Label>How do you feel after eating?</Label>
            <div className="flex gap-2">
              {Object.entries(MOOD_EMOJIS).map(([mood, emoji]) => (
                <Button
                  key={mood}
                  variant={selectedMood === mood ? "default" : "outline"}
                  className="text-2xl"
                  onClick={() => setSelectedMood(mood as keyof typeof MOOD_EMOJIS)}
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>

          {/* Timing Recommendations */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Optimal Meal Timing
            </Label>
            <div className="grid gap-2 text-sm">
              {Object.entries(TIMING_RECOMMENDATIONS).map(([meal, time]) => (
                <div key={meal} className="flex justify-between p-2 bg-accent rounded-md">
                  <span className="capitalize">{meal}</span>
                  <span className="text-muted-foreground">{time}</span>
                </div>
              ))}
            </div>
          </div>

          <Button onClick={handleSave} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Log Meal
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
