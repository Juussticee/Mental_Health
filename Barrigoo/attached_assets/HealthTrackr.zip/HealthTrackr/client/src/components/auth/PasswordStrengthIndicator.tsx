import { cn } from "@/lib/utils";

interface PasswordStrengthIndicatorProps {
  password: string;
}

export function PasswordStrengthIndicator({ password }: PasswordStrengthIndicatorProps) {
  const getStrength = (pass: string) => {
    let score = 0;
    
    // Length check
    if (pass.length >= 8) score++;
    if (pass.length >= 12) score++;
    
    // Character variety checks
    if (/[A-Z]/.test(pass)) score++;
    if (/[a-z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    return Math.min(4, Math.floor(score / 1.5));
  };

  const strength = getStrength(password);

  const getStrengthText = (strength: number) => {
    switch (strength) {
      case 0: return "Poor";
      case 1: return "Weak";
      case 2: return "Fair";
      case 3: return "Strong";
      case 4: return "Very Strong";
      default: return "Poor";
    }
  };

  const getStrengthColor = (strength: number) => {
    switch (strength) {
      case 0: return "bg-red-500";
      case 1: return "bg-red-400";
      case 2: return "bg-orange-400";
      case 3: return "bg-green-400";
      case 4: return "bg-green-600";
      default: return "bg-red-500";
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-1 h-1">
        {[...Array(4)].map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-full flex-1 rounded-full transition-colors duration-200",
              i < strength ? getStrengthColor(strength) : "bg-gray-200"
            )}
          />
        ))}
      </div>
      <p className={cn(
        "text-xs transition-colors",
        strength === 0 ? "text-red-500" :
        strength === 1 ? "text-red-400" :
        strength === 2 ? "text-orange-400" :
        strength === 3 ? "text-green-400" :
        "text-green-600"
      )}>
        Password Strength: {getStrengthText(strength)}
      </p>
    </div>
  );
}
