import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Camera, 
  ChefHat, 
  ListPlus, 
  UploadCloud,
  Loader2 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface RecipeGeneratorProps {
  onAddMeal?: (meal: any) => void;
}

export function RecipeGenerator({ onAddMeal }: RecipeGeneratorProps) {
  const [mode, setMode] = useState<'ingredients' | 'image' | 'requirements'>('ingredients');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    // TODO: Implement image upload and analysis
    toast({
      title: "Coming Soon",
      description: "Image analysis feature is coming soon!",
    });
    setLoading(false);
  };

  const generateRecipe = async (data: any) => {
    setLoading(true);
    // TODO: Implement AI recipe generation
    toast({
      title: "Coming Soon",
      description: "AI recipe generation is coming soon!",
    });
    setLoading(false);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ChefHat className="h-5 w-5" />
          AI Recipe Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Mode Selection */}
          <div className="flex gap-2">
            <Button
              variant={mode === 'ingredients' ? 'default' : 'outline'}
              onClick={() => setMode('ingredients')}
            >
              <ListPlus className="h-4 w-4 mr-2" />
              From Ingredients
            </Button>
            <Button
              variant={mode === 'image' ? 'default' : 'outline'}
              onClick={() => setMode('image')}
            >
              <Camera className="h-4 w-4 mr-2" />
              From Image
            </Button>
            <Button
              variant={mode === 'requirements' ? 'default' : 'outline'}
              onClick={() => setMode('requirements')}
            >
              <ChefHat className="h-4 w-4 mr-2" />
              Custom Requirements
            </Button>
          </div>

          {/* Input Sections */}
          {mode === 'ingredients' && (
            <div className="space-y-4">
              <Textarea 
                placeholder="Enter your ingredients, separated by commas..."
                className="min-h-[100px]"
              />
              <div className="flex items-center gap-2">
                <Button onClick={() => generateRecipe({ type: 'ingredients' })}>
                  Generate Recipe
                </Button>
                <Button variant="outline">
                  Use Available Only
                </Button>
              </div>
            </div>
          )}

          {mode === 'image' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-8 text-center">
                <Input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="image-upload"
                  onChange={handleImageUpload}
                />
                <label
                  htmlFor="image-upload"
                  className="flex flex-col items-center gap-2 cursor-pointer"
                >
                  <UploadCloud className="h-8 w-8 text-muted-foreground" />
                  <span className="text-muted-foreground">
                    Upload food image or take a photo
                  </span>
                </label>
              </div>
            </div>
          )}

          {mode === 'requirements' && (
            <div className="space-y-4">
              <Textarea 
                placeholder="Describe your dietary requirements, health conditions, or nutrition goals..."
                className="min-h-[100px]"
              />
              <Button onClick={() => generateRecipe({ type: 'requirements' })}>
                Generate Meal Plan
              </Button>
            </div>
          )}

          {loading && (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
