import * as React from "react";
import { cn } from "@/lib/utils";

interface CircularProgressProps {
  value: number;
  max: number;
  className?: string;
  size?: number;
}

export function CircularProgress({ value, max, className, size = 200 }: CircularProgressProps) {
  const percentage = Math.min((value / max) * 100, 100);
  const strokeWidth = size / 15;
  const radius = (size - strokeWidth) / 2;
  const circumference = Math.PI * radius;
  const strokeDashoffset = ((100 - percentage) / 100) * circumference;

  return (
    <div className={cn("relative", className)} style={{ width: size, height: size / 2 }}>
      <svg
        className="transform rotate-180"
        style={{ width: size, height: size / 2 }}
        viewBox={`0 0 ${size} ${size / 2}`}
      >
        <path
          d={`M ${strokeWidth / 2},${size / 2}
              A ${radius},${radius} 0 0,1 ${size - strokeWidth / 2},${size / 2}`}
          fill="none"
          stroke="hsl(var(--primary) / 0.2)"
          strokeWidth={strokeWidth}
        />
        <path
          d={`M ${strokeWidth / 2},${size / 2}
              A ${radius},${radius} 0 0,1 ${size - strokeWidth / 2},${size / 2}`}
          fill="none"
          stroke="hsl(var(--primary))"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}
