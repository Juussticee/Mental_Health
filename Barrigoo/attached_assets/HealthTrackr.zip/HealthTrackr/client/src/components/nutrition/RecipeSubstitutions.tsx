import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Wand2 } from "lucide-react";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";

const SUBSTITUTIONS = {
  "White Rice": [
    { item: "Cauliflower Rice", benefits: "Lower carbs, more nutrients" },
    { item: "Quinoa", benefits: "Higher protein, fiber-rich" },
  ],
  "Pasta": [
    { item: "Zucchini Noodles", benefits: "Low-carb, vitamin-rich" },
    { item: "Chickpea Pasta", benefits: "High protein, gluten-free" },
  ],
  "Ground Beef": [
    { item: "Lentils", benefits: "Plant-based protein, high fiber" },
    { item: "Turkey Ground", benefits: "Leaner protein option" },
  ],
  "Mayo": [
    { item: "Avocado", benefits: "Healthy fats, nutrients" },
    { item: "Greek Yogurt", benefits: "High protein, probiotic" },
  ],
};

export function RecipeSubstitutions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wand2 className="h-5 w-5" />
          Healthy Substitutions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {Object.entries(SUBSTITUTIONS).map(([ingredient, alternatives]) => (
            <motion.div
              key={ingredient}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2"
            >
              <h3 className="font-medium">{ingredient}</h3>
              <div className="flex gap-2">
                {alternatives.map((alt) => (
                  <HoverCard key={alt.item}>
                    <HoverCardTrigger asChild>
                      <Button variant="outline" size="sm">
                        {alt.item}
                      </Button>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-64">
                      <div className="space-y-2">
                        <h4 className="font-medium">{alt.item}</h4>
                        <p className="text-sm text-muted-foreground">
                          {alt.benefits}
                        </p>
                      </div>
                    </HoverCardContent>
                  </HoverCard>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
