import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Calendar, 
  Settings,
  Users,
  BarChart,
  Brain
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

const userNavItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/calendar", label: "Calendar", icon: Calendar },
  { href: "/ai", label: "AI Assistant", icon: Brain },
  { href: "/settings", label: "Settings", icon: Settings },
];

const adminNavItems = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/users", label: "Users", icon: Users },
  { href: "/admin/analytics", label: "Analytics", icon: BarChart },
];

export function Sidebar() {
  const [location] = useLocation();
  const isAdmin = location.startsWith("/admin");
  const items = isAdmin ? adminNavItems : userNavItems;

  return (
    <div className="w-64 min-h-screen bg-sidebar border-r">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-sidebar-foreground">
          {isAdmin ? "Admin Panel" : "Food Tracker"}
        </h1>
      </div>
      <nav className="px-4 py-2">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sidebar-foreground hover:bg-sidebar-accent transition-colors",
                  location === item.href && "bg-sidebar-accent"
                )}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </a>
            </Link>
          );
        })}
      </nav>
      <div className="absolute bottom-4 left-4">
        <ThemeToggle />
      </div>
    </div>
  );
}