import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AnimationConfig,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Download, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const sampleData = {
  weeklyProgress: [
    { day: "Mon", calories: 2100, protein: 120, carbs: 250, fat: 70 },
    { day: "Tue", calories: 1950, protein: 115, carbs: 230, fat: 65 },
    { day: "Wed", calories: 2200, protein: 125, carbs: 260, fat: 75 },
    { day: "Thu", calories: 2000, protein: 118, carbs: 240, fat: 68 },
    { day: "Fri", calories: 2150, protein: 122, carbs: 255, fat: 72 },
    { day: "Sat", calories: 1900, protein: 110, carbs: 225, fat: 63 },
    { day: "Sun", calories: 2050, protein: 117, carbs: 245, fat: 69 },
  ],
  monthlyTrends: [
    { month: "Jan", users: 100, meals: 3000, challenges: 50 },
    { month: "Feb", users: 150, meals: 4500, challenges: 75 },
    { month: "Mar", users: 200, meals: 6000, challenges: 100 },
    { month: "Apr", users: 250, meals: 7500, challenges: 125 },
  ],
};

export function AnalyticsAndReports() {
  const [activeChart, setActiveChart] = useState("nutrition");

  const handleExportData = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      sampleData.weeklyProgress.map(row => 
        Object.values(row).join(",")
      ).join("\n");
    
    const link = document.createElement("a");
    link.setAttribute("href", encodeURI(csvContent));
    link.setAttribute("download", "nutrition_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Advanced Analytics</h2>
        <Button onClick={handleExportData}>
          <Download className="mr-2 h-4 w-4" />
          Export Report
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weekly Nutrition Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sampleData.weeklyProgress}>
                  <defs>
                    <linearGradient id="colorCalories" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="calories" 
                    stroke="#8884d8" 
                    fillOpacity={1} 
                    fill="url(#colorCalories)"
                    animationDuration={1500}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <motion.div 
          className="grid md:grid-cols-2 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Protein vs Carbs Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sampleData.weeklyProgress}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar 
                      dataKey="protein" 
                      fill="#82ca9d"
                      animationDuration={1500}
                    />
                    <Bar 
                      dataKey="carbs" 
                      fill="#8884d8"
                      animationDuration={1500}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Growth Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={sampleData.monthlyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="users" 
                      stroke="#8884d8" 
                      animationDuration={1500}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="meals" 
                      stroke="#82ca9d"
                      animationDuration={1500}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}