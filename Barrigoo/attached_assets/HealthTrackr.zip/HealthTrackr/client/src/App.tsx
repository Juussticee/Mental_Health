import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/ThemeProvider";
import Dashboard from "@/pages/dashboard";
import Calendar from "@/pages/calendar";
import Settings from "@/pages/settings";
import Admin from "@/pages/admin";
import AI from "@/pages/ai";
import Login from "@/pages/login";
import Register from "@/pages/register";
import NotFound from "@/pages/not-found";
import React from "react";

// TODO: Replace with actual auth check
const isAuthenticated = () => {
  return false; // For now, always redirect to login
};

function PrivateRoute({ component: Component }: { component: React.ComponentType }) {
  return isAuthenticated() ? <Component /> : <Redirect to="/login" />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/dashboard">
        <PrivateRoute component={Dashboard} />
      </Route>
      <Route path="/calendar">
        <PrivateRoute component={Calendar} />
      </Route>
      <Route path="/settings">
        <PrivateRoute component={Settings} />
      </Route>
      <Route path="/admin">
        <PrivateRoute component={Admin} />
      </Route>
      <Route path="/ai">
        <PrivateRoute component={AI} />
      </Route>
      <Route path="/">
        <Redirect to="/dashboard" />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <Router />
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;