import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { verifyToken } from "@/lib/auth"

// Pages that require authentication
const protectedRoutes = ["/welcome"]

// Pages that are only accessible to unauthenticated users
const authRoutes = ["/"]

export async function middleware(request: NextRequest) {
  // Generate CSRF token if not present
  const csrfToken = request.cookies.get("csrf_token")?.value
  const response = NextResponse.next()

  if (!csrfToken) {
    const newCsrfToken = crypto.randomUUID()
    response.cookies.set("csrf_token", newCsrfToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
    })
  }

  // Set security headers
  response.headers.set("X-Content-Type-Options", "nosniff")
  response.headers.set("X-Frame-Options", "DENY")
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin")
  response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

  // Check authentication for protected routes
  const token = request.cookies.get("auth_token")?.value
  const pathname = request.nextUrl.pathname

  // For protected routes, redirect to login if not authenticated
  if (protectedRoutes.some((route) => pathname.startsWith(route))) {
    if (!token) {
      return NextResponse.redirect(new URL("/", request.url))
    }

    // Verify token validity
    const payload = await verifyToken(token)
    if (!payload) {
      return NextResponse.redirect(new URL("/", request.url))
    }
  }

  // For auth routes, redirect to welcome if already authenticated
  if (authRoutes.some((route) => pathname.startsWith(route))) {
    if (token) {
      const payload = await verifyToken(token)
      if (payload) {
        return NextResponse.redirect(new URL("/welcome", request.url))
      }
    }
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}

