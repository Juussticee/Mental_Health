"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Shield, LogOut, CheckCircle2 } from "lucide-react"

export default function WelcomePage() {
  const router = useRouter()
  const [user, setUser] = useState<{ name?: string; email: string } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem("auth_token")
    if (!token) {
      router.push("/")
      return
    }

    // For demo purposes, extract email from token
    try {
      // Decode JWT payload (second part of token)
      const payload = JSON.parse(atob(token.split(".")[1]))
      setUser({ email: payload.email })
      setLoading(false)
    } catch (error) {
      console.error("Error decoding token:", error)
      localStorage.removeItem("auth_token")
      router.push("/")
    }
  }, [router])

  const handleSignOut = async () => {
    localStorage.removeItem("auth_token")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-pulse text-center">
          <p className="text-lg">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 bg-gray-50 dark:bg-gray-900">
      <div className="w-full max-w-md mx-auto text-center">
        <div className="mb-6 flex justify-center">
          <div className="rounded-full bg-primary/10 p-4">
            <Shield className="h-12 w-12 text-primary" />
          </div>
        </div>

        <h1 className="text-4xl font-bold mb-4">Welcome{user.name ? `, ${user.name}` : ""}!</h1>
        <p className="text-xl text-muted-foreground mb-8">You have successfully signed in with {user.email}</p>

        <div className="space-y-4">
          <div className="rounded-lg border bg-card p-6 text-left shadow-sm">
            <h2 className="text-xl font-semibold mb-2">Security Information</h2>
            <p className="text-muted-foreground mb-4">Your account is protected with our latest security measures:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <div className="rounded-full bg-green-500/10 p-1">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
                <span>Secure JWT authentication</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="rounded-full bg-green-500/10 p-1">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
                <span>CSRF protection</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="rounded-full bg-green-500/10 p-1">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
                <span>Rate limiting for login attempts</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="rounded-full bg-green-500/10 p-1">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
                <span>Secure HTTP headers</span>
              </li>
            </ul>
          </div>

          <Button onClick={handleSignOut} variant="outline" className="w-full gap-2">
            <LogOut className="h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  )
}

