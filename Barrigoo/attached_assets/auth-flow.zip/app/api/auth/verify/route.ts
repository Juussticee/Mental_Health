import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// CSRF protection middleware
function validateCsrfToken(request: NextRequest) {
  const csrfToken = request.headers.get("X-CSRF-Token")
  const storedToken = request.cookies.get("csrf_token")?.value

  if (!csrfToken || !storedToken || csrfToken !== storedToken) {
    return false
  }

  return true
}

export async function POST(request: NextRequest) {
  try {
    // Validate CSRF token
    if (!validateCsrfToken(request)) {
      return NextResponse.json({ success: false, error: "Invalid CSRF token" }, { status: 403 })
    }

    // Get token from request body
    const { token } = await request.json()

    if (!token) {
      return NextResponse.json({ success: false, error: "No token provided" }, { status: 400 })
    }

    // Verify token
    const payload = await verifyToken(token)

    if (!payload) {
      return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 })
    }

    return NextResponse.json({ success: true, user: { email: payload.email } })
  } catch (error) {
    console.error("Error verifying token:", error)
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 })
  }
}

