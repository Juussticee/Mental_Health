import { type NextRequest, NextResponse } from "next/server"
import { signUp } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Get credentials from request body
    const { name, email, password } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json({ success: false, error: "Name, email, and password are required" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ success: false, error: "Invalid email format" }, { status: 400 })
    }

    // Attempt to sign up
    const result = await signUp(name, email, password)

    if (!result.success) {
      const status = result.error === "email_in_use" ? 409 : 400
      return NextResponse.json({ success: false, error: result.error }, { status })
    }

    // Set secure HTTP headers
    const headers = new Headers()
    headers.set("X-Content-Type-Options", "nosniff")
    headers.set("X-Frame-Options", "DENY")
    headers.set("Content-Security-Policy", "default-src 'self'")

    return NextResponse.json(
      { success: true, token: result.token },
      {
        status: 201,
        headers,
      },
    )
  } catch (error) {
    console.error("Error signing up:", error)
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 })
  }
}

