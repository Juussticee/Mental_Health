import { type NextRequest, NextResponse } from "next/server"
import { signIn } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Get client IP for rate limiting
    const ip = request.headers.get("x-forwarded-for") || "127.0.0.1"

    // Get credentials from request body
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ success: false, error: "Email and password are required" }, { status: 400 })
    }

    // Attempt to sign in
    const result = await signIn(email, password, ip.split(",")[0])

    if (!result.success) {
      const status = result.error === "too_many_attempts" ? 429 : 401
      return NextResponse.json({ success: false, error: result.error }, { status })
    }

    // Set secure HTTP headers
    const headers = new Headers()
    headers.set("X-Content-Type-Options", "nosniff")
    headers.set("X-Frame-Options", "DENY")
    headers.set("Content-Security-Policy", "default-src 'self'")

    return NextResponse.json(
      { success: true, token: result.token },
      {
        status: 200,
        headers,
      },
    )
  } catch (error) {
    console.error("Error signing in:", error)
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 })
  }
}

