import { type NextRequest, NextResponse } from "next/server"
import { checkUserExists } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Get email from request body
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ success: false, error: "Email is required" }, { status: 400 })
    }

    // Check if user exists
    const exists = await checkUserExists(email)

    return NextResponse.json({ success: true, exists })
  } catch (error) {
    console.error("Error checking email:", error)
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 })
  }
}

