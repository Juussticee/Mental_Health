"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { signIn, signUp, checkUserExists } from "@/lib/auth"
import { Eye, EyeOff, CheckCircle2, XCircle } from "lucide-react"

export default function AuthForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("signin")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  // Form state for sign in
  const [signInData, setSignInData] = useState({
    email: "",
    password: "",
  })

  // Form state for sign up
  const [signUpData, setSignUpData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  // Password strength state
  const [passwordStrength, setPasswordStrength] = useState(0)
  const [passwordChecks, setPasswordChecks] = useState({
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false,
  })

  // Check if user is already logged in
  useEffect(() => {
    const token = localStorage.getItem("auth_token")
    if (token) {
      router.push("/welcome")
    }
  }, [router])

  // Get CSRF token from meta tag
  const getCsrfToken = () => {
    const metaTag = document.querySelector('meta[name="csrf-token"]')
    return metaTag ? metaTag.getAttribute("content") : ""
  }

  // Check password strength
  const checkPasswordStrength = (password: string) => {
    const checks = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password),
    }

    // Calculate strength (0-100)
    const strength = Object.values(checks).filter(Boolean).length * 20

    return { strength, checks, isStrong: strength >= 60 } // At least 3 criteria met
  }

  // Handle sign in form submission
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      console.log("Attempting to sign in with:", signInData.email)

      // Direct authentication without API call for demo purposes
      const result = await signIn(signInData.email, signInData.password)
      console.log("Sign in result:", result)

      if (result.success) {
        // Store auth token securely
        localStorage.setItem("auth_token", result.token)

        toast({
          title: "Success",
          description: "You have successfully signed in!",
          variant: "default",
        })

        // Redirect to welcome page
        console.log("Redirecting to welcome page...")
        router.push("/welcome")
      } else {
        if (result.error === "user_not_found") {
          toast({
            title: "User not found",
            description: "Would you like to create an account?",
            variant: "default",
            action: (
              <Button variant="outline" onClick={() => setActiveTab("signup")} className="ml-2">
                Sign Up
              </Button>
            ),
          })
          setSignUpData({
            ...signUpData,
            email: signInData.email,
          })
        } else {
          throw new Error(result.error || "Invalid credentials")
        }
      }
    } catch (error) {
      console.error("Sign in error:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to sign in",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Handle sign up form submission
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Client-side validation
      if (!signUpData.name || !signUpData.email || !signUpData.password) {
        throw new Error("Please fill in all fields")
      }

      if (signUpData.password !== signUpData.confirmPassword) {
        throw new Error("Passwords do not match")
      }

      if (!checkPasswordStrength(signUpData.password).isStrong) {
        throw new Error("Password is not strong enough")
      }

      // Check if user already exists
      const userExists = await checkUserExists(signUpData.email)
      if (userExists) {
        toast({
          title: "Account exists",
          description: "An account with this email already exists. Please sign in.",
          variant: "default",
          action: (
            <Button
              variant="outline"
              onClick={() => {
                setActiveTab("signin")
                setSignInData({
                  ...signInData,
                  email: signUpData.email,
                })
              }}
              className="ml-2"
            >
              Sign In
            </Button>
          ),
        })
        setIsLoading(false)
        return
      }

      // Direct registration without API call for demo purposes
      const result = await signUp(signUpData.name, signUpData.email, signUpData.password)

      if (result.success) {
        // Store auth token securely
        localStorage.setItem("auth_token", result.token)

        toast({
          title: "Account created",
          description: "Your account has been created successfully!",
          variant: "default",
        })

        // Redirect to welcome page
        router.push("/welcome")
      } else {
        throw new Error(result.error || "Failed to create account")
      }
    } catch (error) {
      console.error("Sign up error:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to sign up",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Handle email blur to check if user exists
  const handleEmailBlur = async (email: string, isSignUp: boolean) => {
    if (!email || !email.includes("@")) return

    try {
      const userExists = await checkUserExists(email)

      if (isSignUp && userExists) {
        toast({
          title: "Account exists",
          description: "An account with this email already exists. Please sign in.",
          variant: "default",
          action: (
            <Button
              variant="outline"
              onClick={() => {
                setActiveTab("signin")
                setSignInData({
                  ...signInData,
                  email: email,
                })
              }}
              className="ml-2"
            >
              Sign In
            </Button>
          ),
        })
      } else if (!isSignUp && !userExists) {
        toast({
          title: "No account found",
          description: "No account found with this email. Would you like to create one?",
          variant: "default",
          action: (
            <Button
              variant="outline"
              onClick={() => {
                setActiveTab("signup")
                setSignUpData({
                  ...signUpData,
                  email: email,
                })
              }}
              className="ml-2"
            >
              Sign Up
            </Button>
          ),
        })
      }
    } catch (error) {
      // Silently fail on blur checks
      console.error("Error checking email:", error)
    }
  }

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="signin">Sign In</TabsTrigger>
        <TabsTrigger value="signup">Sign Up</TabsTrigger>
      </TabsList>

      <TabsContent value="signin">
        <div className="space-y-4 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signin-email">Email</Label>
              <Input
                id="signin-email"
                type="email"
                placeholder="m@example.com"
                value={signInData.email}
                onChange={(e) => setSignInData({ ...signInData, email: e.target.value })}
                onBlur={(e) => handleEmailBlur(e.target.value, false)}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="signin-password">Password</Label>
                <Button variant="link" className="px-0 font-normal h-auto" type="button">
                  Forgot password?
                </Button>
              </div>
              <div className="relative">
                <Input
                  id="signin-password"
                  type={showPassword ? "text" : "password"}
                  value={signInData.password}
                  onChange={(e) => setSignInData({ ...signInData, password: e.target.value })}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  <span className="sr-only">Toggle password visibility</span>
                </Button>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          {/* Demo credentials */}
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p>Demo credentials:</p>
            <p>Email: test@example.com</p>
            <p>Password: password</p>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="signup">
        <div className="space-y-4 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <form onSubmit={handleSignUp} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signup-name">Name</Label>
              <Input
                id="signup-name"
                type="text"
                placeholder="John Doe"
                value={signUpData.name}
                onChange={(e) => setSignUpData({ ...signUpData, name: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-email">Email</Label>
              <Input
                id="signup-email"
                type="email"
                placeholder="m@example.com"
                value={signUpData.email}
                onChange={(e) => setSignUpData({ ...signUpData, email: e.target.value })}
                onBlur={(e) => handleEmailBlur(e.target.value, true)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <div className="relative">
                <Input
                  id="signup-password"
                  type={showPassword ? "text" : "password"}
                  value={signUpData.password}
                  onChange={(e) => {
                    const newPassword = e.target.value
                    const { strength, checks, isStrong } = checkPasswordStrength(newPassword)
                    setSignUpData({ ...signUpData, password: newPassword })
                    setPasswordStrength(strength)
                    setPasswordChecks(checks)
                  }}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  <span className="sr-only">Toggle password visibility</span>
                </Button>
              </div>

              {/* Password strength meter */}
              {signUpData.password && (
                <div className="mt-2 space-y-2">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Password strength</span>
                      <span>
                        {passwordStrength >= 80
                          ? "Strong"
                          : passwordStrength >= 60
                            ? "Good"
                            : passwordStrength >= 40
                              ? "Fair"
                              : "Weak"}
                      </span>
                    </div>
                    <Progress value={passwordStrength} className="h-1" />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-1">
                      {passwordChecks.length ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-red-500" />
                      )}
                      <span>At least 8 characters</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {passwordChecks.uppercase ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-red-500" />
                      )}
                      <span>Uppercase letter</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {passwordChecks.lowercase ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-red-500" />
                      )}
                      <span>Lowercase letter</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {passwordChecks.number ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-red-500" />
                      )}
                      <span>Number</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {passwordChecks.special ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-red-500" />
                      )}
                      <span>Special character</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-confirm-password">Confirm Password</Label>
              <div className="relative">
                <Input
                  id="signup-confirm-password"
                  type={showConfirmPassword ? "text" : "password"}
                  value={signUpData.confirmPassword}
                  onChange={(e) => setSignUpData({ ...signUpData, confirmPassword: e.target.value })}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  <span className="sr-only">Toggle password visibility</span>
                </Button>
              </div>
              {signUpData.password &&
                signUpData.confirmPassword &&
                signUpData.password !== signUpData.confirmPassword && (
                  <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
                )}
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || passwordStrength < 60 || signUpData.password !== signUpData.confirmPassword}
            >
              {isLoading ? "Signing up..." : "Sign Up"}
            </Button>
          </form>
        </div>
      </TabsContent>
    </Tabs>
  )
}

