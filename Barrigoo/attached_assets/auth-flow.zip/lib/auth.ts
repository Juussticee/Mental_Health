import { jwtVerify, SignJWT } from "jose"

// Secret key for JWT signing - in production, use environment variables
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "complex_secret_key_for_development_only")

// Simulated user database - in production, use a real database
const users: Record<string, { id: string; name: string; email: string; passwordHash: string }> = {
  // Add a default user for testing
  "default-user": {
    id: "default-user",
    name: "Test User",
    email: "test@example.com",
    passwordHash: "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8", // password: "password"
  },
}

// Simulated rate limiting
const loginAttempts: Record<string, { count: number; lastAttempt: number }> = {}

// Check if a user with the given email exists
export async function checkUserExists(email: string): Promise<boolean> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 300))

  return Object.values(users).some((user) => user.email.toLowerCase() === email.toLowerCase())
}

// Hash password - in production, use a proper hashing library like bcrypt
export async function hashPassword(password: string): Promise<string> {
  // This is a simplified hash for demonstration
  // In production, use bcrypt or Argon2
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

// Verify password
async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const passwordHash = await hashPassword(password)
  return passwordHash === hash
}

// Generate JWT token
async function generateToken(userId: string, email: string): Promise<string> {
  return new SignJWT({ sub: userId, email })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(JWT_SECRET)
}

// Verify JWT token
export async function verifyToken(token: string): Promise<{ sub: string; email: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as { sub: string; email: string }
  } catch (error) {
    return null
  }
}

// Check rate limiting
function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const attempt = loginAttempts[ip] || { count: 0, lastAttempt: 0 }

  // Reset attempts after 15 minutes
  if (now - attempt.lastAttempt > 15 * 60 * 1000) {
    loginAttempts[ip] = { count: 1, lastAttempt: now }
    return true
  }

  // Allow max 5 attempts in 15 minutes
  if (attempt.count >= 5) {
    return false
  }

  loginAttempts[ip] = { count: attempt.count + 1, lastAttempt: now }
  return true
}

// Sign in user
export async function signIn(
  email: string,
  password: string,
  ip = "127.0.0.1",
): Promise<{ success: boolean; token?: string; error?: string }> {
  // For development/demo purposes, allow direct login without API call
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Check rate limiting
  if (!checkRateLimit(ip)) {
    return { success: false, error: "too_many_attempts" }
  }

  // Find user by email
  const user = Object.values(users).find((u) => u.email.toLowerCase() === email.toLowerCase())

  if (!user) {
    return { success: false, error: "user_not_found" }
  }

  // Verify password
  const isValid = await verifyPassword(password, user.passwordHash)

  if (!isValid) {
    return { success: false, error: "invalid_credentials" }
  }

  // Generate token
  const token = await generateToken(user.id, user.email)

  return { success: true, token }
}

// Sign up user
export async function signUp(
  name: string,
  email: string,
  password: string,
): Promise<{ success: boolean; token?: string; error?: string }> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Check if user already exists
  if (await checkUserExists(email)) {
    return { success: false, error: "email_in_use" }
  }

  // Validate password complexity
  const hasUppercase = /[A-Z]/.test(password)
  const hasLowercase = /[a-z]/.test(password)
  const hasNumber = /[0-9]/.test(password)
  const hasSpecial = /[^A-Za-z0-9]/.test(password)
  const isLongEnough = password.length >= 8

  if (!(hasUppercase && hasLowercase && hasNumber && hasSpecial && isLongEnough)) {
    return { success: false, error: "password_too_weak" }
  }

  // Hash password
  const passwordHash = await hashPassword(password)

  // Generate user ID
  const userId = crypto.randomUUID()

  // Store user
  users[userId] = {
    id: userId,
    name,
    email: email.toLowerCase(),
    passwordHash,
  }

  // Generate token
  const token = await generateToken(userId, email)

  return { success: true, token }
}

